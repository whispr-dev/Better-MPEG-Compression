
#pragma once
#include <vector>
#include <cstdint>
#include <stdexcept>

namespace wofl {

struct BitWriter {
    std::vector<uint8_t> data;
    uint8_t cur=0;
    int bits=0;
    void put_bit(uint32_t b){
        cur |= (b&1) << (7-bits);
        bits++;
        if(bits==8){ data.push_back(cur); cur=0; bits=0; }
    }
    void put_bits(uint32_t val, int n){
        for(int i=n-1;i>=0;--i) put_bit( (val>>i)&1 );
    }
    void flush(){
        if(bits){ data.push_back(cur); cur=0; bits=0; }
    }
};

struct BitReader {
    const std::vector<uint8_t>& data;
    size_t idx=0;
    int bits=0;
    uint8_t cur=0;
    BitReader(const std::vector<uint8_t>& d): data(d){}
    uint32_t get_bit(){
        if(bits==0){
            if(idx>=data.size()) throw std::runtime_error("BitReader EOF");
            cur = data[idx++]; bits=8;
        }
        uint32_t b = (cur >> (bits-1)) & 1u;
        bits--;
        return b;
    }
    uint32_t get_bits(int n){
        uint32_t v=0;
        for(int i=0;i<n;++i) v = (v<<1) | get_bit();
        return v;
    }
};

} // namespace wofl
