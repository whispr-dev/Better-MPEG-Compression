
#pragma once
#include <vector>
#include <cstdint>
#include <cstdio>
#include <stdexcept>
#include <string>
#include <cstring>
#include <algorithm>

namespace wofl {

struct Wav {
    int sample_rate=0;
    int channels=0;
    std::vector<float> samples; // interleaved float32 -1..+1

    static uint32_t rd32(FILE* f){ uint8_t b[4]; if(fread(b,1,4,f)!=4) throw std::runtime_error("wav eof"); return b[0]|(b[1]<<8)|(b[2]<<16)|(b[3]<<24); }
    static uint16_t rd16(FILE* f){ uint8_t b[2]; if(fread(b,1,2,f)!=2) throw std::runtime_error("wav eof"); return b[0]|(b[1]<<8); }
    static void wr32(FILE* f, uint32_t v){ uint8_t b[4]={uint8_t(v&255),uint8_t((v>>8)&255),uint8_t((v>>16)&255),uint8_t((v>>24)&255)}; fwrite(b,1,4,f); }
    static void wr16(FILE* f, uint16_t v){ uint8_t b[2]={uint8_t(v&255),uint8_t((v>>8)&255)}; fwrite(b,1,2,f); }

    void read(const std::string& path){
        FILE* f = std::fopen(path.c_str(),"rb");
        if(!f) throw std::runtime_error("cannot open wav");
        uint32_t riff = rd32(f); uint32_t sz = rd32(f); uint32_t wave = rd32(f);
        if(riff!=0x46464952 || wave!=0x45564157){ fclose(f); throw std::runtime_error("not wav"); }
        uint16_t audio_fmt=0, num_ch=0, bits_per_sample=0; uint32_t sample_rate_=0;
        long data_pos=-1; uint32_t data_size=0; uint16_t block_align=0;
        while(!feof(f)){
            uint32_t id = rd32(f); uint32_t csz = rd32(f);
            long pos = std::ftell(f);
            if(id==0x20746d66){ // "fmt "
                audio_fmt = rd16(f);
                num_ch = rd16(f);
                sample_rate_ = rd32(f);
                rd32(f); // byte rate
                block_align = rd16(f);
                bits_per_sample = rd16(f);
            } else if(id==0x61746164){ // "data"
                data_pos = std::ftell(f);
                data_size = csz;
                std::fseek(f, csz, SEEK_CUR);
            } else {
                std::fseek(f, csz, SEEK_CUR);
            }
            std::fseek(f, pos + csz, SEEK_SET);
            if(std::ftell(f) >= (long)(8+sz)) break;
        }
        if(data_pos<0){ fclose(f); throw std::runtime_error("no data chunk"); }
        channels = num_ch;
        sample_rate = sample_rate_;
        samples.resize((data_size) / (bits_per_sample/8));
        std::fseek(f, data_pos, SEEK_SET);
        if(bits_per_sample==16){
            for(size_t i=0;i<samples.size();++i){
                int16_t s = (int16_t)rd16(f);
                samples[i] = std::max(-1.0f, std::min(1.0f, s / 32768.0f));
            }
        } else if(bits_per_sample==32 && audio_fmt==3){ // float32
            for(size_t i=0;i<samples.size();++i){
                uint32_t v = rd32(f);
                float fv; std::memcpy(&fv, &v, 4);
                samples[i] = fv;
            }
        } else {
            fclose(f);
            throw std::runtime_error("unsupported WAV format");
        }
        fclose(f);
    }

    void write(const std::string& path, int sr, int ch){
        FILE* f = std::fopen(path.c_str(),"wb");
        if(!f) throw std::runtime_error("cannot write wav");
        uint32_t data_bytes = samples.size()*2;
        // RIFF header
        wr32(f, 0x46464952); // "RIFF"
        wr32(f, 36 + data_bytes);
        wr32(f, 0x45564157); // "WAVE"
        // fmt
        wr32(f, 0x20746d66); // "fmt "
        wr32(f, 16);
        wr16(f, 1); // PCM
        wr16(f, ch);
        wr32(f, sr);
        wr32(f, sr*ch*2);
        wr16(f, ch*2);
        wr16(f, 16);
        // data
        wr32(f, 0x61746164); // "data"
        wr32(f, data_bytes);
        for(float v: samples){
            int16_t s = (int16_t)std::max(-32768.0f, std::min(32767.0f, std::round(v*32767.0f)));
            wr16(f, (uint16_t)s);
        }
        fclose(f);
    }
};

} // namespace wofl
