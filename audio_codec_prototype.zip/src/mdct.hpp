
#pragma once
#include <vector>
#include <cmath>
#include <cassert>

namespace wofl {

// Simple MDCT/IMDCT (power-of-two N, 50% overlap)
struct MDCT {
    size_t N;
    std::vector<float> sinwin;
    MDCT(size_t N_): N(N_), sinwin(N_) {
        assert(N && (N & (N-1))==0);
        for (size_t n=0;n<N;++n){
            sinwin[n] = std::sin(float(M_PI)/N * (n + 0.5f));
        }
    }
    void forward(const std::vector<float>& x, size_t pos, std::vector<float>& X) const {
        X.assign(N, 0.0f);
        for (size_t k=0;k<N;++k){
            float acc=0.0f;
            for (size_t n=0;n<2*N;++n){
                float sample = (pos+n < x.size()) ? x[pos+n] : 0.0f;
                float w = std::sin(float(M_PI)/(2*N) * (n + 0.5f));
                float phi = float(M_PI)/N * (n + 0.5f + N/2.0f) * (k + 0.5f);
                acc += w * sample * std::cos(phi);
            }
            X[k]=acc;
        }
    }
    void inverse(const std::vector<float>& X, std::vector<float>& y, size_t pos) const {
        // Overlap-add into y (assumes sized)
        for (size_t n=0;n<2*N;++n){
            float acc=0.0f;
            for (size_t k=0;k<N;++k){
                float phi = float(M_PI)/N * (n + 0.5f + N/2.0f) * (k + 0.5f);
                acc += X[k]*std::cos(phi);
            }
            float w = std::sin(float(M_PI)/(2*N) * (n + 0.5f));
            float v = 2.0f/N * w * acc;
            if (pos+n < y.size()) y[pos+n] += v;
        }
    }
};

} // namespace wofl
