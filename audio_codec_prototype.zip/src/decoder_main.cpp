
#include "wav.hpp"
#include "fft.hpp"
#include "analysis.hpp"
#include "bitstream.hpp"
#include "parametric.hpp"
#include "residual.hpp"
#include <cstdio>
#include <string>
#include <vector>
#include <algorithm>

using namespace wofl;

int main(int argc, char** argv){
    if(argc < 3){
        std::fprintf(stderr, "Usage: decoder <input.bin> <output.wav>\n");
        return 1;
    }
    std::string in = argv[1];
    std::string out = argv[2];
    // Read whole file
    FILE* f = std::fopen(in.c_str(), "rb");
    if(!f){ std::perror("fopen"); return 2; }
    std::vector<uint8_t> buf;
    std::fseek(f, 0, SEEK_END);
    long sz = std::ftell(f);
    std::fseek(f, 0, SEEK_SET);
    buf.resize(sz);
    std::fread(buf.data(), 1, sz, f);
    std::fclose(f);

    BitReader br(buf);
    uint32_t sync = br.get_bits(8);
    if(sync!=0xDE){ std::fprintf(stderr, "bad container sync\n"); return 3; }
    int sr = (int)br.get_bits(24);
    int ch = (int)br.get_bits(8);

    auto fh = read_header(br);
    int N = fh.nfft;
    int hop = fh.hop;
    int K = fh.K;
    int channels = fh.channels;

    std::vector<float> L;
    // Pre-allocate a rough length (unknown; we will resize as needed)
    L.resize(1, 0.0f);

    MagQ mq(0.12f);
    ParametricState pst{};
    ResidualQ rq(0.01f);
    MDCT mdct(N/2);

    size_t pos = 0;
    while(true){
        // Try decoding one frame; break on errors
        size_t old_idx = br.idx;
        int old_bits = br.bits;
        try{
            // Parametric
            auto peaks = decode_tracks(br, pst, mq);
            // Synthesize
            std::vector<cpx> X(N, cpx(0,0));
            synthesize_tracks(peaks, X);
            std::vector<float> recon(N, 0.0f);
            istft_frame(recon, 0, N, X);

            // Residual
            std::vector<float> C(N/2, 0.0f);
            decode_residual(br, C, rq);
            std::vector<float> resid(2*(N/2), 0.0f);
            mdct.inverse(C, resid, 0);

            // Mix
            if(L.size() < pos + recon.size()) L.resize(pos + recon.size(), 0.0f);
            if(L.size() < pos + resid.size()) L.resize(pos + resid.size(), 0.0f);
            for(size_t i=0;i<recon.size();++i) L[pos+i] += recon[i];
            for(size_t i=0;i<resid.size();++i) L[pos+i] += resid[i];

            pos += hop;
        } catch(...) {
            // restore and break
            br.idx = old_idx; br.bits = old_bits;
            break;
        }
    }

    // Rebuild stereo from Mid/Side (we encoded only Mid here; Side assumed zero for prototype)
    std::vector<float> stereo;
    stereo.resize(L.size()*2);
    for(size_t i=0;i<L.size();++i){
        float mid = L[i];
        float side = 0.0f;
        stereo[2*i+0] = mid + side;
        stereo[2*i+1] = mid - side;
    }
    Wav w; w.samples = stereo; w.write(out, sr, 2);
    std::fprintf(stderr, "Decoded %zu samples\n", stereo.size());
    return 0;
}
