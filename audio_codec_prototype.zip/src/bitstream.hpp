
#pragma once
#include "bitio.hpp"
#include "rice.hpp"
#include <vector>
#include <cstdint>
#include <string>

namespace wofl {

struct FrameHeader {
    uint16_t nfft;
    uint16_t hop;
    uint16_t K;
    uint8_t  channels;
    uint8_t  reserved{0};
};

inline void write_header(BitWriter& bw, const FrameHeader& h){
    bw.put_bits(0xAC, 8); // sync
    bw.put_bits(h.nfft, 16);
    bw.put_bits(h.hop, 16);
    bw.put_bits(h.K, 16);
    bw.put_bits(h.channels, 8);
}

inline FrameHeader read_header(BitReader& br){
    uint32_t sync = br.get_bits(8);
    if(sync!=0xAC) throw std::runtime_error("bad sync");
    FrameHeader h{};
    h.nfft = (uint16_t)br.get_bits(16);
    h.hop  = (uint16_t)br.get_bits(16);
    h.K    = (uint16_t)br.get_bits(16);
    h.channels = (uint8_t)br.get_bits(8);
    return h;
}

} // namespace wofl
