
#include "wav.hpp"
#include "fft.hpp"
#include "analysis.hpp"
#include "psy.hpp"
#include "parametric.hpp"
#include "bitstream.hpp"
#include "residual.hpp"
#include <cstdio>
#include <string>
#include <vector>
#include <algorithm>

using namespace wofl;

int main(int argc, char** argv){
    if(argc < 3){
        std::fprintf(stderr, "Usage: encoder <input.wav> <output.bin> [--nfft=2048] [--hop=512] [--K=128]\n");
        return 1;
    }
    std::string in = argv[1];
    std::string out = argv[2];
    int N = 2048, hop = 512, K = 128;
    for(int i=3;i<argc;++i){
        std::string a = argv[i];
        if(a.rfind("--nfft=",0)==0) N = std::stoi(a.substr(7));
        else if(a.rfind("--hop=",0)==0) hop = std::stoi(a.substr(6));
        else if(a.rfind("--K=",0)==0) K = std::stoi(a.substr(4));
    }
    Wav w; w.read(in);
    int ch = w.channels;
    int sr = w.sample_rate;
    std::vector<float> L, R;
    L.reserve(w.samples.size()/ch);
    R.reserve(w.samples.size()/ch);
    for(size_t i=0;i<w.samples.size();i+=ch){
        float l = w.samples[i];
        float r = (ch>1)? w.samples[i+1] : l;
        L.push_back(0.5f*(l+r)); // Mid
        R.push_back(0.5f*(l-r)); // Side
    }

    BitWriter bw;
    // write simple container header
    bw.put_bits(0xDE, 8); // container sync
    bw.put_bits(sr, 24);
    bw.put_bits(ch, 8);

    FrameHeader fh{ (uint16_t)N, (uint16_t)hop, (uint16_t)K, (uint8_t)ch };
    write_header(bw, fh);

    std::vector<cpx> X(N);
    std::vector<float> mag, ph;
    std::vector<int> bands;
    bark_band_edges(N, sr, bands);
    MagQ mq(0.12f);
    ParametricState pst{};
    ResidualQ rq(0.01f);
    MDCT mdct(N/2);

    // Output raw bitstream per frame
    for(size_t pos=0; pos+N < L.size(); pos += hop){
        // STFT of Mid
        stft_frame(L, pos, N, X);
        mag_phase(X, mag, ph);
        // Band energy for salience
        auto bandE = band_energy(mag, bands);
        auto peaks = topk_peaks(mag, ph, K);
        // Salience keep: drop peaks with salience < threshold
        std::vector<Peak> kept;
        kept.reserve(peaks.size());
        for(const auto& p: peaks){
            float s = salience_of_peak(bandE, bands, p.bin, p.mag*p.mag);
            if(s > 0.1f) kept.push_back(p);
        }
        // Write parametric
        encode_tracks(bw, kept, pst, mq);

        // Synthesize back to spectrum and time to get residual Mid
        std::vector<cpx> Xsyn(N, cpx(0,0));
        synthesize_tracks(kept, Xsyn);
        std::vector<float> recon(N, 0.0f);
        istft_frame(recon, 0, N, Xsyn); // single frame iSTFT overlap isn't perfect; OK for residual demo
        // Residual Mid over 2*(N/2) window for MDCT
        std::vector<float> resid(2*(N/2), 0.0f);
        for(size_t i=0;i<resid.size();++i){
            size_t t = pos + i;
            float mid = (t<L.size() ? L[t] : 0.0f);
            float approx = (i<recon.size() ? recon[i] : 0.0f);
            resid[i] = mid - approx;
        }
        std::vector<float> C; mdct.forward(resid, 0, C);
        // Simple threshold based on total energy
        float e=0.0f; for(float c: C) e += c*c; e = std::sqrt(e / (float)C.size());
        float thresh = 0.05f * e + 1e-6f;
        encode_residual(bw, C, thresh, rq);
    }

    bw.flush();
    // Write to file
    FILE* f = std::fopen(out.c_str(), "wb");
    if(!f){ std::perror("fopen"); return 2; }
    std::fwrite(bw.data.data(), 1, bw.data.size(), f);
    std::fclose(f);
    std::fprintf(stderr, "Encoded %zu bytes\n", bw.data.size());
    return 0;
}
